<?php
/**
 * Coin-flip results for pool-play ties (1.0.33).
 *
 * Standings mark exact ties as "Coin flip required". Once the flip is done,
 * staff record the order here (Tools → SWAT Coin Flips) and the Game Day
 * standings show real seeds. A result applies only when the tied group in
 * that division is exactly the listed teams, so it cannot reorder anything else.
 *
 * Stored format (one per line):  Division | Winner > Next > ...
 *
 * @package SWAT_Tournament_OS_Child
 */

defined( 'ABSPATH' ) || exit;

const SWAT_CHILD_COIN_FLIP_OPTION = 'swat_child_coin_flip_results';

/**
 * Default text used until the option has been saved once.
 *
 * @return string
 */
function swat_child_coin_flip_default_text() {
	// Pumpkin Smash 2026, 9U Open: flip done Oct 17 — GBC is the 4 seed, Dirtbags the 5 seed.
	return "9U Open | GBC Prospects Confer > Dirtbags Baseball ESB";
}

/**
 * Parse the stored text into [{division, order:[...]}].
 *
 * @param string $text Raw lines.
 * @return array
 */
function swat_child_coin_flip_parse( $text ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
		$line = trim( $line );
		if ( '' === $line || 0 === strpos( $line, '#' ) || false === strpos( $line, '|' ) ) {
			continue;
		}
		list( $division, $teams ) = array_map( 'trim', explode( '|', $line, 2 ) );
		$order = array_values( array_filter( array_map( 'trim', explode( '>', $teams ) ), 'strlen' ) );
		if ( '' === $division || count( $order ) < 2 ) {
			continue;
		}
		$out[] = array(
			'division' => sanitize_text_field( $division ),
			'order'    => array_map( 'sanitize_text_field', $order ),
		);
	}
	return $out;
}

/**
 * Current coin-flip results for the front end.
 *
 * @return array
 */
function swat_child_coin_flip_results() {
	$text = get_option( SWAT_CHILD_COIN_FLIP_OPTION, null );
	if ( null === $text || false === $text ) {
		$text = swat_child_coin_flip_default_text();
	}
	return (array) apply_filters( 'swat_child_coin_flip_results', swat_child_coin_flip_parse( $text ) );
}

/**
 * Tools → SWAT Coin Flips.
 *
 * @return void
 */
function swat_child_coin_flip_menu() {
	add_management_page( 'SWAT Coin Flips', 'SWAT Coin Flips', 'manage_options', 'swat-coin-flips', 'swat_child_coin_flip_page' );
}
add_action( 'admin_menu', 'swat_child_coin_flip_menu' );

/**
 * Render and save the admin page.
 *
 * @return void
 */
function swat_child_coin_flip_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$saved = false;
	if ( isset( $_POST['swat_coin_flips'] ) ) {
		check_admin_referer( 'swat_child_coin_flips', 'swat_child_coin_flips_nonce' );
		$raw   = sanitize_textarea_field( wp_unslash( $_POST['swat_coin_flips'] ) );
		update_option( SWAT_CHILD_COIN_FLIP_OPTION, $raw, false );
		$saved = true;
	}
	$text = get_option( SWAT_CHILD_COIN_FLIP_OPTION, null );
	if ( null === $text || false === $text ) {
		$text = swat_child_coin_flip_default_text();
	}
	?>
	<div class="wrap">
		<h1>SWAT Coin Flips</h1>
		<?php if ( $saved ) : ?><div class="notice notice-success"><p>Saved. Standings update on the next refresh.</p></div><?php endif; ?>
		<p>One line per tie: <code>Division | Coin-flip winner &gt; Next team</code>. Team names must match the schedule exactly. A line applies only when those exact teams are tied in that division. Delete a line to undo it.</p>
		<form method="post">
			<?php wp_nonce_field( 'swat_child_coin_flips', 'swat_child_coin_flips_nonce' ); ?>
			<textarea name="swat_coin_flips" rows="10" class="large-text code"><?php echo esc_textarea( $text ); ?></textarea>
			<?php submit_button( 'Save coin flips' ); ?>
		</form>
	</div>
	<?php
}
