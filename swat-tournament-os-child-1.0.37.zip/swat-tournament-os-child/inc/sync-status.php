<?php
/**
 * Tools → SWAT Playbook Sync (1.0.37).
 *
 * Shows whether the background Playbook check is running, when each current
 * event was last pulled from Playbook, and lets an admin pull one now.
 * Uses swat_child_source_refresh() and the known event list only.
 */
defined( 'ABSPATH' ) || exit;

/**
 * Events worth showing: live today, starting within 7 days, or ended within 2 days.
 *
 * @return array<string,array> Keyed by source key.
 */
function swat_child_sync_status_events() {
	$today = current_time( 'Y-m-d' );
	$soon  = gmdate( 'Y-m-d', strtotime( $today . ' +7 days' ) );
	$recent = gmdate( 'Y-m-d', strtotime( $today . ' -2 days' ) );
	$out = array();
	foreach ( swat_child_source_events() as $key => $event ) {
		$end = (string) ( $event['end'] ?? $event['start'] );
		if ( (string) $event['start'] <= $soon && $end >= $recent ) {
			$out[ $key ] = $event;
		}
	}
	uasort(
		$out,
		static function ( $a, $b ) {
			return ( (int) swat_child_source_is_live( $b ) <=> (int) swat_child_source_is_live( $a ) ) ?: strcmp( (string) $a['start'], (string) $b['start'] );
		}
	);
	return $out;
}

/** Human age: "45 sec ago", "3 min ago", "2 hr ago". */
function swat_child_sync_age( $ts ) {
	if ( ! $ts ) {
		return 'never';
	}
	$age = max( 0, time() - (int) $ts );
	if ( $age < 90 ) {
		return $age . ' sec ago';
	}
	if ( $age < 2 * HOUR_IN_SECONDS ) {
		return round( $age / 60 ) . ' min ago';
	}
	return round( $age / HOUR_IN_SECONDS ) . ' hr ago';
}

function swat_child_sync_status_menu() {
	add_management_page( 'SWAT Playbook Sync', 'SWAT Playbook Sync', 'manage_options', 'swat-playbook-sync', 'swat_child_sync_status_page' );
}
add_action( 'admin_menu', 'swat_child_sync_status_menu' );

function swat_child_sync_status_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$events = swat_child_sync_status_events();
	$notice = '';
	if ( isset( $_POST['swat_sync_key'] ) ) {
		check_admin_referer( 'swat_child_sync_refresh', 'swat_child_sync_nonce' );
		$key = sanitize_text_field( wp_unslash( $_POST['swat_sync_key'] ) );
		$all = swat_child_source_events();
		if ( isset( $all[ $key ] ) ) {
			$cache = 'swat_child_source_' . md5( $key );
			delete_transient( $cache . '_failed' );
			$r = swat_child_source_refresh( $all[ $key ] );
			$notice = ! empty( $r['ok'] )
				? '<div class="notice notice-success"><p>Pulled ' . esc_html( $all[ $key ]['name'] ) . ' from Playbook: ' . (int) $r['games'] . ' games.</p></div>'
				: '<div class="notice notice-error"><p>Playbook pull failed for ' . esc_html( $all[ $key ]['name'] ) . ': ' . esc_html( (string) ( $r['reason'] ?? 'unknown error' ) ) . '. Saved scores were kept.</p></div>';
		}
	}
	$last_tick = (int) get_option( 'swat_child_source_last_tick', 0 );
	$next_tick = wp_next_scheduled( 'swat_child_source_tick' );
	$cron_off  = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
	$tick_late = ! $last_tick || time() - $last_tick > 5 * MINUTE_IN_SECONDS;
	$cron_url  = site_url( 'wp-cron.php?doing_wp_cron' );
	?>
	<div class="wrap">
		<h1>SWAT Playbook Sync</h1>
		<?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above ?>
		<h2>Background check</h2>
		<p>
			Last run: <strong><?php echo esc_html( swat_child_sync_age( $last_tick ) ); ?></strong>
			· Next run: <strong><?php echo $next_tick ? esc_html( wp_date( 'g:i:s a', $next_tick ) ) : 'not scheduled'; ?></strong>
			· Runs every 2 minutes; events being played today are pulled every run.
		</p>
		<?php if ( $tick_late ) : ?>
			<div class="notice notice-warning inline"><p><strong>The background check has not run in the last 5 minutes.</strong>
			<?php echo $cron_off ? 'WordPress cron is turned off (DISABLE_WP_CRON), so a server cron job must call it.' : 'WordPress only runs it when someone visits the site, and page caching can stop that.'; ?>
			Fix: add a cron job (hosting panel → Cron Jobs, or a free service such as cron-job.org) that opens this URL every minute:<br><code><?php echo esc_html( $cron_url ); ?></code></p></div>
		<?php else : ?>
			<p>Healthy. For guaranteed timing on busy weekends, also add a cron job that opens <code><?php echo esc_html( $cron_url ); ?></code> every minute.</p>
		<?php endif; ?>
		<h2>Events</h2>
		<?php if ( ! $events ) : ?>
			<p>No events today, in the next 7 days, or in the last 2 days.</p>
		<?php else : ?>
		<table class="widefat striped">
			<thead><tr><th>Event</th><th>Dates</th><th>Last pulled from Playbook</th><th>Games</th><th>Status</th><th></th></tr></thead>
			<tbody>
			<?php foreach ( $events as $key => $event ) :
				$cache  = 'swat_child_source_' . md5( $key );
				$stored = get_option( $cache );
				$ts     = is_array( $stored ) ? (int) ( $stored['checked_at'] ?? 0 ) : 0;
				$games  = is_array( $stored ) ? count( (array) ( $stored['games'] ?? array() ) ) : 0;
				$live   = swat_child_source_is_live( $event );
				if ( get_transient( $cache . '_lock' ) ) {
					$status = 'Pulling now…';
				} elseif ( get_transient( $cache . '_failed' ) ) {
					$status = '<span style="color:#b32d2e">Last pull failed · retrying</span>';
				} elseif ( $live && ( ! $ts || time() - $ts > 5 * MINUTE_IN_SECONDS ) ) {
					$status = '<span style="color:#b32d2e">Behind (live event)</span>';
				} elseif ( $live ) {
					$status = '<span style="color:#008a20">Live · current</span>';
				} else {
					$status = $ts ? 'Current' : 'Not pulled yet';
				}
				?>
				<tr>
					<td><strong><?php echo esc_html( $event['name'] ); ?></strong><?php echo $live ? ' <span class="dashicons dashicons-controls-play" title="Being played today"></span>' : ''; ?></td>
					<td><?php echo esc_html( $event['start'] . ( ! empty( $event['end'] ) && $event['end'] !== $event['start'] ? ' – ' . $event['end'] : '' ) ); ?></td>
					<td><?php echo esc_html( swat_child_sync_age( $ts ) ); ?></td>
					<td><?php echo (int) $games; ?></td>
					<td><?php echo $status; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed markup ?></td>
					<td><form method="post" style="margin:0">
						<?php wp_nonce_field( 'swat_child_sync_refresh', 'swat_child_sync_nonce' ); ?>
						<input type="hidden" name="swat_sync_key" value="<?php echo esc_attr( $key ); ?>">
						<button type="submit" class="button">Pull now</button>
					</form></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php endif; ?>
		<p>Game Day phones re-check this site every 30 seconds during live games and every 60 seconds otherwise. A score entered in Playbook normally appears on the site within about 2–3 minutes. A failed pull never erases saved scores.</p>
	</div>
	<?php
}
