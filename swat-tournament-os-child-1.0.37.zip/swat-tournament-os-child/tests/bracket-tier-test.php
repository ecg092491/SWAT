<?php
/**
 * Gold / Silver split-final labels (inc/bracket-schedule.php), using the live
 * Playbook fixtures of 2026-10-08. Run: php tests/bracket-tier-test.php
 */
define( 'ABSPATH', __DIR__ . '/' );
function add_filter() {}
function add_action() {}
function absint( $v ) { return abs( (int) $v ); }
require __DIR__ . '/../inc/bracket-schedule.php';

$fail = 0;
$check = static function ( $name, $ok ) use ( &$fail ) { if ( ! $ok ) { ++$fail; echo "FAIL $name\n"; } };
$fx = static function ( $pid, $div, $num, $sched, $wt = 0 ) { return array( 'id' => 900000000 + $pid, 'playbook_id' => (string) $pid, 'division' => $div, 'game_number' => (string) $num, 'schedule_id' => (string) $sched, 'game_type_id' => 2, 'winner_to' => $wt, 'loser_to' => 0, 'time' => '21:00' ); };

// FNL 10/9: 8U split final (game 2 arrives first to prove ordering by game number) + single 12U final.
$l = swat_child_bracket_tier_labels( array( $fx( 7875, '8U Open', 2, 1485 ), $fx( 7874, '8U Open', 1, 1485 ), $fx( 7873, '12U Open', 1, 1486 ) ) );
$check( 'FNL 8U game 1 = 8U Gold Championship', ( $l['pb:7874']['bracket_name'] ?? '' ) === '8U Gold' && 'Championship' === $l['pb:7874']['round'] );
$check( 'FNL 8U game 2 = 8U Silver Championship', ( $l['pb:7875']['tier'] ?? '' ) === 'Silver' && 'Championship' === $l['pb:7875']['round'] );
$check( 'FNL 12U single final not relabelled', ! isset( $l['pb:7873'] ) );

// SNL 10/10: 11U split final.
$l = swat_child_bracket_tier_labels( array( $fx( 7893, '11U Open', 1, 1496 ), $fx( 7894, '11U Open', 2, 1496 ) ) );
$check( 'SNL 11U Gold / Silver', 'Gold' === ( $l['pb:7893']['tier'] ?? '' ) && 'Silver' === ( $l['pb:7894']['tier'] ?? '' ) );

// Pink Ribbon 10U: linked semis feed a final -> untouched.
$l = swat_child_bracket_tier_labels( array( $fx( 7884, '10U Open', 1, 1490, 900007885 ), $fx( 7883, '10U Open', 2, 1490, 900007885 ), $fx( 7885, '10U Open', 3, 1490 ) ) );
$check( 'Linked bracket untouched', array() === $l );

// Pool games ignored; override filter wins.
$pool = $fx( 1, '8U Open', 1, 1 ); $pool['game_type_id'] = 1;
$l = swat_child_bracket_tier_labels( array( $pool, $fx( 7874, '8U Open', 1, 1485 ), $fx( 7875, '8U Open', 2, 1485 ) ), array( '7875' => array( 'bracket' => '8U Consolation', 'round' => 'Final' ) ) );
$check( 'Pool games ignored', ! isset( $l['id:1'] ) );
$check( 'Override applied', '8U Consolation' === ( $l['pb:7875']['bracket_name'] ?? '' ) && 'Final' === $l['pb:7875']['round'] );

// Labels reach games (resolved teams keep the label).
$games = swat_child_apply_bracket_labels( array( array( 'id' => 900007875, 'playbook_id' => '7875', 'away' => 'Carolina Clippers 8U' ) ), swat_child_bracket_tier_labels( array( $fx( 7874, '8U Open', 1, 1485 ), $fx( 7875, '8U Open', 2, 1485 ) ) ) );
$check( 'Applied after seeds resolve', 'Silver' === ( $games[0]['tier'] ?? '' ) );

// Pumpkin Smash 10/18 (9U and 11U): finals fed by "Winner # N"; G1 -> G2 is Silver, G3 + G4 -> G5 is Gold.
$ph = static function ( $pid, $num, $time, $away, $home ) use ( $fx ) { $g = $fx( $pid, '11U Open', $num, 1600 ); $g['time'] = $time; $g['date'] = '2026-10-18'; $g['away'] = $away; $g['home'] = $home; return $g; };
$g2 = $ph( 9002, 2, '11:00', 'Copperheads Camo', 'Winner # 1' );
$g5 = $ph( 9005, 5, '17:00', 'Winner # 3', 'Winner # 4' );
$l = swat_child_bracket_tier_labels( array( $g2, $g5 ) );
$check( 'Fed finals only: G2 = 11U Silver', '11U Silver' === ( $l['pb:9002']['bracket_name'] ?? '' ) );
$check( 'Fed finals only: G5 = 11U Gold Championship', '11U Gold' === ( $l['pb:9005']['bracket_name'] ?? '' ) && 'Championship' === $l['pb:9005']['round'] );
$l = swat_child_bracket_tier_labels( array( $ph( 9001, 1, '09:00', 'Division Place 6', 'Division Place 7' ), $g2, $ph( 9003, 3, '13:00', 'Division Place 1', 'Division Place 4' ), $ph( 9004, 4, '13:00', 'Division Place 2', 'Division Place 3' ), $g5 ) );
$check( 'Full bracket: G1 joins Silver', 'Silver' === ( $l['pb:9001']['tier'] ?? '' ) && ! isset( $l['pb:9001']['round'] ) );
$check( 'Full bracket: G3, G4 join Gold', 'Gold' === ( $l['pb:9003']['tier'] ?? '' ) && 'Gold' === ( $l['pb:9004']['tier'] ?? '' ) );
$check( 'Full bracket: G5 Gold, G2 Silver', 'Gold' === ( $l['pb:9005']['tier'] ?? '' ) && 'Silver' === ( $l['pb:9002']['tier'] ?? '' ) );

echo $fail ? "$fail failure(s)\n" : "13 bracket tier checks, 0 failure(s)\n";
exit( $fail ? 1 : 0 );
