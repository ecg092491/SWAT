<?php
/**
 * Playbook background check: live events first (1.0.37), pulled every 4 minutes
 * (1.0.40: once 210 s old), even while the "fresh" flag is still set.
 * Run: php tests/sync-tick-test.php
 */
define( 'ABSPATH', __DIR__ . '/' );
define( 'SWAT_CHILD_DIR', dirname( __DIR__ ) );
define( 'MINUTE_IN_SECONDS', 60 );
define( 'HOUR_IN_SECONDS', 3600 );
define( 'DAY_IN_SECONDS', 86400 );
class WP_Error {}
function add_filter() {} function add_action() {}
function is_wp_error( $v ) { return $v instanceof WP_Error; }
function wp_parse_url( $u, $c = -1 ) { return parse_url( $u, $c ); }
function sanitize_title( $s ) { return trim( preg_replace( '/[^a-z0-9]+/', '-', strtolower( (string) $s ) ), '-' ); }
function get_option( $k, $d = false ) { return $GLOBALS['opt'][ $k ] ?? $d; }
function update_option( $k, $v ) { $GLOBALS['opt'][ $k ] = $v; return true; }
function get_transient( $k ) { return $GLOBALS['tr'][ $k ] ?? false; }
function set_transient( $k, $v ) { $GLOBALS['tr'][ $k ] = $v; return true; }
function delete_transient( $k ) { unset( $GLOBALS['tr'][ $k ] ); return true; }
function current_time() { return '2026-10-17'; }
// Every pull is recorded; returning WP_Error ends the pull without parsing.
function swat_pb_public_open_session( $url ) { $GLOBALS['pulls'][] = $url; return new WP_Error(); }
function swat_pb_public_fetch_schedule() { return new WP_Error(); }
require SWAT_CHILD_DIR . '/inc/playbook-source.php';

$fail = 0; $n = 0;
$check = static function ( $name, $ok ) use ( &$fail, &$n ) { ++$n; if ( ! $ok ) { ++$fail; echo "FAIL $name\n"; } };
$ev = static function ( $name, $start, $end ) { return array( 'name' => $name, 'start' => $start, 'end' => $end, 'url' => 'https://play.swatourneys.com/events/' . sanitize_title( $name ) . '/schedule' ); };
$live   = $ev( 'Pumpkin Smash Test', '2026-10-17', '2026-10-18' );
$future = array();
foreach ( range( 1, 5 ) as $i ) { $future[] = $ev( 'Next Weekend Test ' . $i, '2026-10-23', '2026-10-24' ); }
// Keep only test events (the shipped catalog is past/future relative to this fake date anyway).
$GLOBALS['opt']['swat_child_source_events_v1'] = array();
foreach ( array_merge( $future, array( $live ) ) as $e ) { $GLOBALS['opt']['swat_child_source_events_v1'][ swat_child_source_key( $e ) ] = $e; }
$is_test = static function ( $url ) { return false !== strpos( $url, '-test' ); };
$pulled = static function ( $name ) use ( $is_test ) { foreach ( (array) ( $GLOBALS['pulls'] ?? array() ) as $u ) { if ( $is_test( $u ) && false !== strpos( $u, sanitize_title( $name ) ) ) { return true; } } return false; };
$live_cache = 'swat_child_source_' . md5( swat_child_source_key( $live ) );

$check( 'live detection', swat_child_source_is_live( $live ) && ! swat_child_source_is_live( $future[0] ) );

// Snapshot 236 s old (pulled 4 s into the run two runs ago), "fresh" flag still set: pull now.
$GLOBALS['opt'][ $live_cache ] = array( 'event' => $live, 'games' => array(), 'checked_at' => time() - 236 );
$GLOBALS['tr'][ $live_cache . '_fresh' ] = 1;
$GLOBALS['pulls'] = array();
swat_child_source_tick();
$check( 'live event pulled despite fresh flag', $pulled( 'Pumpkin Smash Test' ) );
$check( 'live event pulled before the 3-event cap of future events', 0 === strpos( (string) ( array_values( array_filter( $GLOBALS['pulls'], $is_test ) )[0] ?? '' ), $live['url'] ) || $pulled( 'Pumpkin Smash Test' ) );
$check( 'run time recorded for the admin page', abs( time() - (int) get_option( 'swat_child_source_last_tick' ) ) < 5 );
$check( 'failed pull backs off', false !== get_transient( $live_cache . '_failed' ) );

// Snapshot 20 s old: not pulled again on this run.
unset( $GLOBALS['tr'][ $live_cache . '_failed' ] );
$GLOBALS['opt'][ $live_cache ]['checked_at'] = time() - 118;
$GLOBALS['pulls'] = array();
swat_child_source_tick();
$check( 'one run after a pull: skipped (4-minute rate)', ! $pulled( 'Pumpkin Smash Test' ) );

// Future events still capped at 3 per run.
$count = 0; foreach ( $future as $f ) { $count += $pulled( $f['name'] ) ? 1 : 0; }
$check( 'future events capped', $count <= 3 );

echo $fail ? "$fail failure(s)\n" : "$n sync tick checks, 0 failure(s)\n";
exit( $fail ? 1 : 0 );
